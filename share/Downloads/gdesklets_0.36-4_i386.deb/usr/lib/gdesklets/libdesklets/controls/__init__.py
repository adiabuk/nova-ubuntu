from main.Control import Control
from plugin.Interface import Interface
from plugin import Permission
from utils import FakeSelf, Bind

