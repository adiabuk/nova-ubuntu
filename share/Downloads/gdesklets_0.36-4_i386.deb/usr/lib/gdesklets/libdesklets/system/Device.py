class Device:

    def __init__(self): pass

    def poll(self): pass
