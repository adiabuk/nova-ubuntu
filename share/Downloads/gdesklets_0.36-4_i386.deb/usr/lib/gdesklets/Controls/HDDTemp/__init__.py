def get_class():

    import impl
    return impl.HDDTemp
