from X86 import X86
from Sparc import Sparc
from PPC import PPC
from Generic import Generic
